<?php
/**
 * Created by JetBrains PhpStorm.
 * User: admin2
 * Date: 3/22/12
 * Time: 12:49 AM
 * To change this template use File | Settings | File Templates.
 */

phpinfo();