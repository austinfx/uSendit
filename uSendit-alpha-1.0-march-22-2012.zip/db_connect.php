<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Jason Brashear
 * Date: 3/21/12
 * Time: 5:56 PM
 */

$db_host="localhost";
$db_user="your_user";
$db_password="password";
$db="content";

$cid = mysql_connect($db_host,$db_user,$db_password);
if(!$cid) {
    echo "Failed to connect";
}
else {
    echo "At this point we are connected";
}
