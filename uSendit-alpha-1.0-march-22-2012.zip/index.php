<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Jason Brashear
 * Date: 3/21/12
 * Time: 2:22 PM
 * To change this template use File | Settings | File Templates.
 */
?>

    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>PDS File Large File Uploads</title>
</head>
<body>

<form enctype="multipart/form-data" action="upload.php" method="POST">
    Please choose a file: <input name="uploaded" type="file" /> <?php echo 'post_max_size = ' . ini_get('post_max_size') . "\n"; ?><br />
    Your name: <input  type="text" name="pds_full_name" maxlength="80" size="30"><br />
    Your Email: <input  type="text" name="pds_email" maxlength="80" size="30"><br />
    Recipient Email: <input  type="text" name="eu_email" maxlength="80" size="30"><br />
    Nte to User: <textarea  name="comments" maxlength="1000" cols="25" rows="6"></textarea><br />
    <input type="submit" value="Upload" />
</form>

</body>
</html>